<?php
set_time_limit(0);
require_once '/home/libs/config.php';


$dir = '/home/tmp/oio.pw/sites/youtube/';
$list = scandir($dir);
foreach($list as $file){
    if($file === '.' || $file === '..') continue;
    if(is_dir($file)) continue;
    if(strstr($file, '.mp4') or strstr($file, '.webm')) continue;
    if(strstr($file, '.html')){
        $html = file_get_contents($dir . $file, null, null, 0, 900);
        preg_match_all("/<title[\s\S]*?>(.*?)<\/title>/iUs", $html, $title);
        $title = isset($title[1][0])?trim($title[1][0]):"";
        $title = preg_replace("/\r\n|\r|\n/", '', $title);
		echo $file .' '. $title ."<br>\n";
    }
}