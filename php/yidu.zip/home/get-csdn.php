<?php
set_time_limit(0);
require_once '/home/libs/config.php';


$libs_path = LIBS;
$article_path = ARTICLE;
$cache_path = CACHE;
$webpage_path = WEBPAGE;
$tmp_path = TMP;

$savedir = $article_path.'/csdn/';


# https://www.jb51.net/article/24980.htm
$url = 'https://blog.csdn.net/tfnmdmx/article/details/118859514';

# 提交URL
header("Content-type: text/html; charset=utf-8");
$cli = preg_match("/cli/i", php_sapi_name());
if($cli){
    fwrite(STDOUT, "Enter url:");
    $url = trim(fgets(STDIN));
}
if(empty($_GET['url'])and!$cli)die('<br><br><center>请使用参数?url=https://...</center>' . form_html());
if(isset($_GET['url']))$url = $_GET['url'];
echo $url . "\r\n";

# 提取当前URL的文件名
$url_array = pathinfo(parse_url($url)['path']);
$fn = $url_array['basename'];
$fn_1 = $url_array['filename'];
if(isset($url_array['extension']))$fn_ext = $url_array['extension'];

$html = file_get_contents($url);
file_put_contents($cache_path .'/csdn_'. $fn . '.bak', $html);

# 修改内容
preg_match('/<title>(.*?)<\/title>/iUs', $html, $title);
$title = $title ? $title[1] : '';
$head = add_head($title, $url);

$body = explode('</article>', $html, 2)[0];
$body = explode('<main>', $body, 2)[1];
$body = "<body><br>\r\n<main>\r\n". $body . "</article>\r\n<hr><b>" . $url . "</b>\r\n</div><br>\r\n</main>\r\n</body>\r\n</html>\r\n";

# 去掉js和css风格，提取title重构head
$search = array(
            "'<script[^>]*?>.*?</script>'si", # 去掉 javascript
            "'<style[^>]*?>.*?</style>'si",   # 去掉 css
            "'<link[/!]*?[^<>]*?>'si",        # 去掉 link
            /* "'<meta\sname[^>]*?>'si"          # 去掉 meta */
            "'<meta[/!]*?[^<>]*?>'si",        # 去掉meta
        );
$replace = array("", "", "",);
$body = preg_replace($search, $replace, $body);
$body = str_replace('</h1>', '</h1><br>', $body);
$html = $head . $body;

$html_array2 = explode('<img class="article-read-img', $html, 2);
$html_array3 = explode('<article class="baidu_pl">', $html_array2[1], 2);
$html = $html_array2[0] . "</div></div></div></div>\r\n</div></div>\r\n<article class=\"baidu_pl\">\r\n" . $html_array3[1];

require_once $libs_path.'/beautify-html.php';
$beautify = new Beautify_Html(array(
    'indent_inner_html' => false,
    'indent_char' => " ",
    'indent_size' => 2,
    'wrap_line_length' => 32786,
    'unformatted' => ['code', 'pre'],
    'preserve_newlines' => false,
    'max_preserve_newlines' => 32786,
    'indent_scripts'    => 'normal', // keep|separate|normal
));

$html = $beautify->beautify($html);

file_put_contents($savedir . $fn_1 . '.html', $html);

echo '文章保存于 ' . $savedir . $fn_1 . '.html';









# ================函数区，基本无需修改================#
function form_html(){
    header("Content-type: text/html; charset=utf-8");
    $html = "<html><head><title>Get CSDN blog posts</title></head>\r\n<body><center><br>\r\n<form action=\"" . php_self() . "\"method='GET'/>\r\n";
    $html .= '<b>CSDN blog\'s URL:<input type="text" name="url" size=50 value="https://blog.csdn.net"/>' . "\r\n" . '<input type="submit" value="Send"/>';
    $html .= "</b>\r\n</form>\r\n<br>\r\n";
    echo $html;
}

# 获取当前PHP文件名
function php_self(){
    $php_self = substr($_SERVER['PHP_SELF'], strrpos($_SERVER['PHP_SELF'], '/') + 1);
    return $php_self;
}



function add_head($title, $url){
    $head = '
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <link rel="canonical" href="'.$url.'" />
  <title>'.$title.'</title>
  <link rel="stylesheet" type="text/css" href="https://csdnimg.cn/release/blogv2/dist/pc/css/detail_enter-a1cde2271d.min.css">
  <link rel="stylesheet" href="https://csdnimg.cn/release/blogv2/dist/mdeditor/css/editerView/ck_htmledit_views-044f2cf1dc.css">
</head>';
    return $head;
}

# 检测URL在当前网络环境中是否有效
// $header = get_headers($url);
// if(!preg_grep("/200/", $header)) die('请求的url可能出错');

// $curl = curl_init($url);
// curl_setopt($curl, CURLOPT_NOBODY, true);
// $result = curl_exec($curl);
// $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
// curl_close($curl);
// if($statusCode != 200) die("\r\n请求的url可能出错\r\n");

# 获取url的内容
// $options = array('http' => array(
//                                 'method' => 'POST',
//                                 'header' => 'Content-type:application/x-www-form-urlencoded;charset=UTF-8',
//                                 'content' => $stringData   # 需要获取的内容
//                                 ),
//                  "ssl" => array(
//                                 "verify_peer" => false,
//                                 "verify_peer_name" => false,
//                                 )
//                 );
// $context = stream_context_create($options);
// $html = file_get_contents($url, false, $context);