<?php
define("DATA",    "/data");
define("ARTICLE", "/data/article");
define("CACHE",   "/data/cache");
define("WEBPAGE", "/data/webpage");
define("TMP",     "/data/tmp");

define("LIBS", "/home/libs");


