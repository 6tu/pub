<?php

namespace HeadlessChromium\Exception;

use Exception;

class DomException extends Exception
{
}
