<?php
set_time_limit(0);
ini_set("display_errors", "On");
error_reporting(E_ALL | E_STRICT);

require_once '/home/libs/config.php';

$libs_path = LIBS;
$article_path = ARTICLE;
$cache_path = CACHE;
$webpage_path = WEBPAGE;
$tmp_path = TMP;

require_once $libs_path . '/function.php';
require_once($libs_path . '/chrome-php/autoload.php');

$t1 = time();
$cli = preg_match("/cli/i", php_sapi_name()) ? true : false;
if($cli){
    $url = $argv[1];
}else{
    if(empty($_GET)){
        echo html_form();
        exit;
    }
    $url = $_GET['url'];
}

$time = date('YmdH');
$fn_key = str_pad(crc32($url), 10, '0'); # CRC32输出长度: 8-9-10位
$info_url = parse_url($url);
if(!empty($info_url['path'])) $info_path = pathinfo($info_url['path']);
else $info_path = '';
if(!empty($info_path['filename'])) $file = $time .'-'. $info_path['filename'];
else $file = $time .'-'. $fn_key;
$ext = array('html' => '.html', 'png' => '.png', 'pdf' => '.pdf',);
$fn = $cache_path .'/'.$file;

if(strpos(PHP_OS, "Linux")!==false) $bin = "chromium";
if(strpos(PHP_OS, "WIN")!==false)   $bin = "D:\bin\ChromePortable\chrome.exe";
use HeadlessChromium\BrowserFactory;
$browserFactory = new BrowserFactory($bin);# 留空为调用默认的'chrome'
# start sheadless chrome
# 在 chrome-php/chrome/src/Browser/BrowserProcess.php 的418行 加入 --no-sandbox
# $options['noSandbox']  $args[] = '--no-sandbox';
# posix_getuid()依赖于POSIX扩展，需安装 php-process。POSIX扩展不支持在Windowns中使用。
if(getmyuid() == 0)  $args['noSandbox'] = true; # root用户 whoami ,
else $args['noSandbox'] = false;
$browser = $browserFactory -> createBrowser(); # 留空为默认 'proxyServer'=>'127.0.0.1:8080','keepAlive' => true, [$args['noSandbox'],]
try{
    # creates a new page and navigate to an URL
    $page = $browser -> createPage();
    $page -> setUserAgent('Android 12; Mobile; rv:68.0) Gecko/68.0 Firefox/98.0"');
    $page -> navigate($url) -> waitForNavigation();
    $html = $page->getHtml(10000); # 可以精简网页
    # get page title
    $pageTitle = $page -> evaluate('document.title') -> getReturnValue();
    # get page content
    $pageContent = $page -> evaluate('document.documentElement.innerHTML') -> getReturnValue();
    file_put_contents($fn. $ext['html'], $pageContent);

    // file_put_contents($fn. '2.html', $html);
    # screenshot - Say "Cheese"!😄
    // $page -> screenshot() -> saveToFile($fn. $ext['png']);
    # pdf
    // $page -> pdf(['printBackground' => false]) -> saveToFile($fn. $ext['pdf'],  10000);
}finally{
    # bye
    $browser -> close();
}
$t2 = time();
if(!$cli){ echo html_form();}
echo "<br>\r\n    " . ($t2 - $t1) .'    <a href="'. $fn. $ext['html'] .'">'. $pageTitle .'</a>';



/*
 * headless（无界面）浏览器常用的包文件 selenium、 Puppeteer
 *
 * 项目地址 https://github.com/chrome-php/chrome
 * curl -sS https://getcomposer.org/installer | php
 * composer require chrome-php/chrome
 *
 * Windows ChromePortable: https://allinfa.com/software/
 * Linux chrome：apt/yum install chromium (Ubuntu 可能是 chromium-browser)
 *
 * 不建议使用google-chrome，比较麻烦
 * wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
 * apt install ./google-chrome-stable_current_amd64.deb
 *
 * chromium / google-chrome --headless --disable-gpu --no-sandbox --dump-dom(或者 --screenshot 或者--print-to-pdf) https://g.cn
 *
 * 相关项目 https://github.com/php-webdriver/php-webdriver
 * chromedriver 提供了操作 Chrome 的api ，是 Selenium 控制Chrome 的桥梁。
 * 最新的chromedriver版本：
 * https://sites.google.com/a/chromium.org/chromedriver/downloads
 * https://sites.google.com/chromium.org/driver/
 * https://chromedriver.storage.googleapis.com/
 *
 * nano ~/.profile
 * export PATH="$PATH:/opt/chromedriver"
 * source ~/.profile
 *
 */