<?php
set_time_limit(0);
require_once '/home/libs/config.php';



/**
 * 用 openssl 的非对称加密变更 php-proxy 密码
 *
 * *** 非对称加密只支持 RSA 不支持 ECC 公钥
 *
 * 生成私钥和证书
 * openssl req -utf8 -sha512 -nodes -new -x509 -days 3650 -newkey rsa:4096 -keyout rsa_private.key -out rsa_certificate.crt -config openssl.cnf
 * 私钥生成RSA公钥
 * openssl rsa -in rsa_private.key -pubout -out rsa_public.key
 *
 * 生成随机码
 * php：     echo base64_encode(openssl_random_pseudo_bytes(8)) ."\n\n";
 * shell：   passwd=`openssl rand -base64 8`
 *
 * Windows 系统中的 openssl 版本
 * https://raw.githubusercontent.com/openssl/openssl/master/apps/openssl.cnf
 * https://wiki.openssl.org/index.php/Binaries
 * http://wiki.overbyte.eu/wiki/index.php/ICS_Download
 * http://wiki.overbyte.eu/arch/openssl-3.1.0-win64.zip
 *
 */

$sign = base64_encode('php-proxy'); //crc32('php-proxy');
$query = '/cps.php?changepw='.$sign;
# url 地址从 php-proxy.json 中获取，也可以在下行自行定义
$url = '';

$json_path = '/bin/php-proxy/php-proxy.json';
$remind = 'Windows系统中，该文件如果与当前脚本不在同一盘内，需要指定盘符，如 e:/path/to/php-proxy.json';


if(!file_exists($json_path)) die("<h2>没有检测到 php-proxy.json 文件<h2><br>\n" . $remind);
$json = file_get_contents($json_path);
$json = str_replace("\r", "", $json);
$array = explode("\n", $json);
$fetchserver = explode('"', $array[1])[3];
if(empty($url)) $url = pathinfo($fetchserver)['dirname'].$query;
echo $url ."\n\n";
# exit;

$options = array(
    "ssl" => array(
        "verify_peer" => false,
        "verify_peer_name" => false,
    ),
);
$response = file_get_contents($url, false, stream_context_create($options));
echo $response ."\n\n";

/* *********** RSA PRIVATE KEY 私钥解密数据*************** */

$private_key = private_key();
openssl_private_decrypt(base64_decode($response), $decrypted, $private_key);
echo $decrypted;

$passwd = $decrypted;
$new = '"password": "'. $passwd .'",';
$json = str_replace($array[2], $new, $json);

file_put_contents($json_path, $json);




function private_key(){
    $private_key = '-----BEGIN PRIVATE KEY-----
MIIJQwIBADANBgkqhkiG9w0BAQEFAASCCS0wggkpAgEAAoICAQDiWAFpJwvXKiZe
sf8k1eJwTabLAtredRpMPSkpcqZHwCsN8Qq9MwHrCGFCl6eBCNlva5k+EYaKzNl6
vShxelLXFWATFZZlWjxpaYKy4Uhfhw+FXVl4LUp0ENGHoAdCh7yVDUQOYTUjV2xJ
ZFROqtese+P1SmCpZmMOmxhEj7PUYN1Dm9jHalfMc+2vEqfO8KcgDWGaBjaej+GI
OhQvd1aWFZR8HlqM5kQRGbjT+RwXy0E5Uc1Bxw7Du5tV4hvjQYXCA+XHYZLgSAIB
7yzy7ECgsiI27Fr2PSUT4QwskTmJsftcRYVt0Jn2YHu8HcbEtQuynPaIYNlRS1WZ
9x7Me4af8FYzZLWOoriO5YT36G3ymM7CUs6Er4T52xWvR/3T1b59+5KFNugGORgz
75QR2hX/AFQeoSj6nx/w1uG4HSk1w80cDHEW/+INCEM38hPGuG3SZJoPxFHU0c4D
2N+zzF3mrPJQbQnNuu/3pAanvyviv+LtDKSiT/WlPLfgbFdVPsJ3BNpjapqJGbeE
wyoe2fco8zROSBdmHBREhzg0ZreyifDlhZNn5p5cwHggrJQm0UBLre6sValsIpGL
Xm+GQpV9AboXz1jApNDrYHSYzU4LOH926CoHr9fmJ6B4gJuGUHprKf5KCTm0YUmg
QJJRxfLkbxq9Jx1Y2q7SpyYqLndmxQIDAQABAoICABkoiAuck/PYEwi+hyocff1W
nD3/dL16TbCAsdUSEcpy4TY8/yEVjNaHiWwB+FPe3HBGiPN9tjMyXtAGO3sViiSv
Ew07/ooIdCORXz4rzUQU+pQr0piJjDeHcQq+rl/mP39fyJtCkcn6WyZzOO2/jpZ0
9NscZ88cetEySwm/4VCvbZiot3k+6EBo+FfX3oAhfqoQ4rLgkuyf+IUQU5MNFDo9
btI2+4CizZkK/2DMVSON65OH9KUlj44RCcyLg+cILupoTX+SaGV2i4aUg64CtZJH
CoeJUPkCxd7GSnifscIM3vAcKB8TKzHX+pjnxGKz7vds+/gfr7gaBAtHjQxUhJuH
5nPmYFq1gxbbZpSSoSMneL/lWAq6lY3+1Si3dWwUBbYk63kUlxsVUMxaMk/sWVGg
4UByi2pAkknun7IwJU5A0JBLkKdTenx9Z/YEKwyuz+tkDJRZouH4UETFBAW1akiu
xByO4/caNq9vua5TgPL4/xq2GRBvgAUvO0ze3SOY0ykd+0lVXKccN3lpVP6iS7RX
aCZazZQmttqyrM56xPZST1UBDyY64K0xFB/t1fFOX76JB6jERNpPew6fY4FUAwNC
sdlfvmyDMNgd3zYWsvVbMs9IJRbSQnbdEXQC4AcIbrwPQearJje0l6SJaWjbCV2A
fzTqCFsvH5KipD7zZeTBAoIBAQD7f3K4W+v7vlkKKK/A6A1IDi7VRdZOsksTf+Uc
R7RPuB8kJS9fDT6RBhUrBfwTw6xEndk6zQ61ugI98sH71Z+IxlYl+NJufuyqE/AN
5g7UR5K86Oq4k/UKI8GAEje0DX3eCe/BAm+pjMCqO+tehzP5nG1exrxgPl50igTt
FmUWkgGFh2fDleH8N3uMbyhwwNI4D6/XD4U60/aJU3p8PVQ5MQDJaoG5NbEQS4QY
ImN1volu2c5ve2E/cVfev2JayBCjGzMlyGonVlFdBZMp6FQRjBIplBFWQHvoKI/Y
OkKMrdvUJrvXY9ZROPLBPNww7Efam8diEadyNrXGgusRYorlAoIBAQDmZUhU57dJ
NH/02+et3iXRGSi0aX01ZMmUiMj4xD/W7oUgFNPPuuGlymeeoTvdOfPFAvWdU+YC
FbM+ZnjivKIWTu+BVGh6wvr6uz2x/e3OO+zA6H+noNwZwEF+U0RFuCGASEEUCLQB
DbBPe/pzimWAxvUD0TFZ64KfL2rtjMu//5yxywVUQbKGFURHUjg9zHKheKeLlW++
cRYc+jX37Bscu31UiO9iSPOZfu8h5mFrh8V8zbWKMEV1hOHu+1bByH5kB2OLFZLu
qY9AhLlqf7yqAttxIokzZf/eW1otD7fli2wjyDNUlBEq4npBv1YLB1SqHoNM2MNU
8CuPTZl6o05hAoIBAQCVLr2DJGuv8fJpN0dB26R9OISJWBrOpa4pC/WAt/v6SdKX
I0OdU4Lojb4ivjMQGkLmlOeVnKt8GrFXw9dTph0zCctyTM2uY7XJEXiVFgF35Fjj
nBoXkRSKhjky2huWv2YJPsWsLODFp0tl75MniHXJPAQYczSstnJbGL/hTyZ5o/Qp
G+/uMctSTCsKW6mWcJqCTLPWk0tJYRBd11nRtqNuJWY9E+ONVI8KhnD9y/BJmNN3
INX2hS5jbr1b0RTrmr9bsTe+0so9OVOcJUFtW3X6zqa7aSx7iFa3mM/yyGRPhJXg
m3VTR9KKbYh6HbrTfmUFBODZiHVWJ6Pd9CyyLE0NAoIBABRoUkDbCXwdf1wEAoB/
FeBwlw9r7KBHHife+dY3I+R42ifeUGitCAG0bPs7Et9km7gOrAzUeqIio+7aCski
pkTNlx9gh6SgErUU0sEqWd8TpcPslCoX8IcDZYm3/GskhSsku0b4AmG5ga14sNV9
I8KFXPyKkhGB798DxzflacLG9G03K3CsJREFXzfmC39F1b2Bv214vh4jTC8i5pbg
PgKMhOxw+Ks/BPzKpondKzHoI9ELM5Ja9jwTmiOd9bBSfweDNAkEzy/+quavGvFZ
ATAZ8rARvA9mcISUmOc25jYZ5GlC+XD7cI3Y47VhKlDtxE0RSNYMuTiT0XfvCrI3
NuECggEBAOqPW8KXSGreQfL2s43XYm6UTjKPJYOO8vHOqw5O1iaj5A2L3lYkthjv
9FELUXpF8qr+UXCIsqP6z964WqYM1UcSN5LAIQpDEZTdUkpzNCfMdnCDQbKBPGFb
kH5AYq9yh20awliE3Le7Q2fu0YSYfJdCMzOLHyN9ac9MTn/AETaKs4Z/dEHsJrp4
oLGNgF8pcV8wYnIE/M0yoB42FnqOkuvZWIxV0fByHO33eINHikugI1deO2AaOXkN
Nzfz1IF29/6emyZ1YUntOen94tLPLKpWbesdul7EYjkqMjYnUO7uD1CMeJDWAubA
83rwRkmvH/BqubmvC1xYayZGzXa4dyw=
-----END PRIVATE KEY-----';
    return $private_key;
}
