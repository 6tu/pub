<?php
set_time_limit(0);
require_once '/home/libs/config.php';


$libs_path = LIBS;
$article_path = ARTICLE;
$cache_path = CACHE;
$webpage_path = WEBPAGE;
$tmp_path = TMP;

$time = date('YmdHis');
//$fn_key = str_pad(crc32($url), 10, '0'); # CRC32输出长度: 8-9-10位


## ================ 提交URL ================ ##
header("Content-type: text/html; charset=utf-8");
$cli = preg_match("/cli/i", php_sapi_name());
if($cli){
    # print_r($argv);
    if(!empty($argv[1])) $url = $argv[1];
    else{
        fwrite(STDOUT, "Enter url:");
        $url = trim(fgets(STDIN));
    }
}
if(empty($_GET['url']) and !$cli) die('<br><br><center>请使用参数?url=https://...</center>' . form_html());
if(isset($_GET['url'])) $url = $_GET['url'];
// echo "\r\n\r\n" . $url;

$savedir = $article_path . '/phpcn/';



## ================ URL的文件名 ================ ##
$url_array = pathinfo(parse_url($url)['path']);
$fn = $url_array['basename'];
$fn_1 = $url_array['filename'];
if(isset($url_array['extension']))$fn_ext = $url_array['extension'];
$file = $savedir . $fn;


# 获取url的内容
# wget保存无后缀文件名的文件
$cmd = 'wget --html-extension --adjust-extension --no-check-certificate -O ' . $file . ' "' . $url . '" 2>&1';
exec($cmd, $out, $status);
$html = file_get_contents($file);
for($i = 0; $i < 100; $i++){
    $html = str_replace("\t", "    ", $html);
    $html = str_replace("\r\n", "\n", $html);
    $html = str_replace("\r", "\n", $html);
    $html = str_replace(" \n", "\n", $html);
    $html = str_replace("\n\n", "\n", $html);
    $html = str_replace(' ">', '">', $html);
    $html = str_replace(' >', '>', $html);
}

# 修改内容
preg_match('/<title>(.*?)<\/title>/iUs', $html, $title);
$title = $title ? $title[1] : '';
$head = add_head($title, $url);

$c = explode('<html><body>', $html, 2)[1];
$article = explode('</body></html>', $c, 2)[0]; // <div class="wzconZzwz" >'

$ct = explode('<div class="wzContent">', $html, 2)[1];
$header = explode('<div class="wzconLine">', $ct, 2)[0]; // <div class="wzconZzwz" >'
$header = preg_replace("'<div[^>]*?>'", "\n", $header);
$header = preg_replace("'</div>'", "\n", $header);
$header = str_replace('<img ', '<img width=30 ', $header);
$header = '<div class="article-top">'. $header . '</div>';

$html =  $head .'<body>'.$header. '<div class="article">'. $article.'</div><hr>'.$url . '<br><br></body></html>';

$html = str_replace('<div class="contentsignin">登录后复制</div>', '', $html);




$html = beautify_html($html);


# 添加语法加亮风格
$html = preg_replace("'<pre[^>]*?>'", "\n<pre class=\"brush:php;toolbar:false\">\n", $html);
$html = str_replace(array("<pre", "</pre>"), array("\r\n<pre", "\r\n</pre>\r\n"), $html);
if(strpos($html, '</pre>') !== false){
    /* $html = preg_replace("'<div[^>]*?>'iUs", '<div>', $html); */
    $html = preg_replace("'<span[^>]*?>'iUs", '', $html);
    $html = preg_replace("'</span>'iUs", '', $html);
    $html .= add_style();
}



file_put_contents($file, $html);



echo ' %chrome%\\chrome.exe \\home\\article\\phpcn\\' . $fn_1 .".html\r\n\r\n";


# ================函数区，基本无需修改================#
function form_html(){
    header("Content-type: text/html; charset=utf-8");
    $html = "<html><head><title>Get php 中文网 posts</title></head>\r\n<body><center><br>\r\n<form action=\"" . php_self() . "\"method='GET'/>\r\n";
    $html .= '<b>php 中文网\'s URL:<input type="text" name="url" size=50 value="https://blog.csdn.net"/>' . "\r\n" . '<input type="submit" value="Send"/>';
    $html .= "</b>\r\n</form>\r\n<br>\r\n";
    echo $html;
}






# HTML 格式化
function beautify_html($html){
    require_once 'libs/beautify-html.php';
    $beautify_config = array(
        'indent_inner_html' => false,
        'indent_char' => " ",
        'indent_size' => 2,
        'wrap_line_length' => 32786,
        'unformatted' => ['code', 'pre', 'span'],
        'preserve_newlines' => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts' => 'normal', // keep|separate|normal
    );
    $beautify = new Beautify_Html($beautify_config);
    $html = $beautify -> beautify($html);
    return $html;
}

function add_head($title, $url){
    $head = '
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <link rel="canonical" href="'.$url.'" />
  <title>'.$title.'</title>
  <style>
    body,html{
        width: 90%;
        height:100%;
        margin: auto;
        line-height: 1.8;
        background: #;
        color: #000
    }
    div.article-bar-top{
        color:#999aaa;
        width:88%;
        display:-webkit-box;
        display:-ms-flexbox;
        display:flex
    }
    .bar-content{
        display:-webkit-box;
        display:-ms-flexbox;
        display:flex;-ms-flex-wrap:wrap;
        flex-wrap:wrap;-webkit-box-align:center;-ms-flex-align:center;
        align-items:center;
        padding-left:12px
    }
    .article-type-img{
        width:36px;
        height:32px;
        line-height:32px
    }
  </style>
</head>';
    return $head;
}


function add_style(){
    $style = '
<script type="text/javascript" src="http://localhost/reader/libs/styles/SyntaxHighlighter/js/shCore.js"></script>
<script type="text/javascript" src="http://localhost/reader/libs/styles/SyntaxHighlighter/js/shBrushPhp.js"></script>
<link type="text/css" rel="stylesheet" href="http://localhost/reader/libs/styles/SyntaxHighlighter/css/shCore.css" />
<link type="text/css" rel="stylesheet" href="http://localhost/reader/libs/styles/SyntaxHighlighter/css/shThemeLiuQing.css" />
<style>
  .syntaxhighlighter{
      width: 740;
      padding-top:40px;padding-bottom:20px;
      border: 1px solid #333;
      background: url("http://localhost/reader/libs/styles/SyntaxHighlighter/top_bg.svg");
      background-size: 43px;
      background-repeat: no-repeat;
      margin-bottom: -7px;
      border-radius: 15px;
      background-position: 16px 12px;
      padding-left: 10px;
      font-size: 0.8em !important;
      }
      .gutter{
      display: none;
      }
</style>
<script type="text/javascript">
  SyntaxHighlighter.all();
</script>
    ';
    return $style;
}
