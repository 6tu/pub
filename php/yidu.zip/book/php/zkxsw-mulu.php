<?php
$path = 'd:/xs/';
file_put_contents($path . 'list.html','');
$file_array = array_diff(scandir($path), array('..', '.'));
$file_array = array(58671,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,);

foreach($file_array as $value){
	$file = $path . $value;
	echo $file . "\r\n";
    $c = file_get_contents($file);
	$c = str_replace('</li>', "</li>\r\n", $c);
	$l = explode('<ul class="section-list fix ycxsid">', $c)[1];
	$list = explode('<li><a href="/58/58671/127257822.html">第1章 兽血沸腾</a></li>', $l)[0];

	$list = str_replace('<li><a href="/58/58671/170281117.html">第2314章 别跑，来洗刷耻辱啊</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/170281095.html">第2313章 当然是，早有布置</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/170281093.html">第2312章 开战，疯袭</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/170195119.html">第2311章 堵援兵，抢神梭船</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/170195107.html">第2310章 我是黑鳞，秒杀圣武</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/170195095.html">第2309章 集体退魔，再入结界</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/170057332.html">第2308章 定立，少脉主</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/170057331.html">第2307章 恐怖天赋，齐齐突破</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/170057330.html">第2306章 他调兵，我也调兵</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/169931231.html">第2305章 承认魔脉，你们也配？</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/169931218.html">第2304章 魔人，是邪恶的</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/169931207.html">第2303章 冲突？这是好事！</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/169931196.html">第2302章 他的狠，埋下祸根</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/169931179.html">第2301章 犹豫者，非死即伤</a></li>', "", $list);
	$list = str_replace('<li><a href="/58/58671/169931154.html">第2300章 鳞片散，恢复人身</a></li>', "", $list);
	
	
for($i = 0; $i < 100; $i++){
    $list = str_replace("\t", "    ", $list);
    $list = str_replace("\r\n", "\n", $list);
    $list = str_replace("\r", "\n", $list);
    $list = str_replace(" \n", "\n", $list);
    $list = str_replace("\n\n", "\n", $list);
	
}

	
	file_put_contents($path . 'list.html', $list, FILE_APPEND);
}