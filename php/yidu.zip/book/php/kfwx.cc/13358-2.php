<?php
$path = '13358/';
$patharray = array_diff(scandir($path), array('..', '.', 'index.html', 'src',));
foreach($patharray as $pathinfo){
    $pathinfo = $path . $pathinfo;
    $c = file_get_contents($pathinfo);
    $c = str_replace('&-->>', '-->>', $c);

    if(strpos($c, '-->>') !== false){
        $start = mb_strpos($c, '-->>');
        $str = mb_substr($c, $start-10, 20);
		$array_str = explode("\n", $str);
        // echo mb_substr_count($c, '-->>') . '    '; # 统计标记出现的次数
        // echo $pathinfo . "    '" . $str . "'\n";   # 提取的全部字串
		if(strpos($array_str[0], '-->>') !== false) $str = $array_str[0];
		else $str = $array_str[1];
        # 找到重复，然后替换
        $s = str_replace('　', '', $str); # 去掉全角空格
        $res = preg_match("/[\x7f-\xff]/", $s);
        if($res){
            echo '包含中文    ';
            $array = explode('-->>', $str);
            $dup = '-->>' . longest($array[0], $array[1]);
            $dup2 = '-->>';
        }else{
            echo '咩有中文    ';
            $dup = $s;
            $dup2 = '-->>';
        }
        $c = str_replace($dup, $dup2, $c);
        // echo $pathinfo . "    '" . $dup . "'\n";
        file_put_contents('article/' . $pathinfo, $c);
        # 替换后检测
        $start = mb_strpos($c, '-->>');
        $str = mb_substr($c, $start-10, 20);
        echo $pathinfo . "    '" . $str . "'\n\n";
    }else echo 'move ' . $pathinfo . '  article/' . $pathinfo . "\r\n";
}

# 找到两个字符串完全相同的部分
# 赋值给$longest，当找到有最长的字符串，就替换$longest
# 这里的$len不能大于$str1的长度，否则可能无限循环，
# 由于使用mb_substr()和strpos()，它的$start,$end皆不能大于$len，否则可能无限循环，
function longest($str1 = '', $str2 = ''){
    $start = 0;
    $end = 1;
    $longest = '';
    $len = mb_strlen($str1); #$len不能大于这个数，否则可能无限循环，
    for($i = 0;$i < $len;){
        if($start >= $len)break;
        if($end > $len)break;
        $part = mb_substr($str1, $start, $end);
        if(strpos($str2, $part) !== false){
            if(mb_strlen($part) > mb_strlen($longest)) $longest = $part;
            $end++;
        }else{
            $i++;
            $start = $i-1;
            $end = 1;
        }
    }
    return $longest;
}
