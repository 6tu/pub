<?php
$path = '13358/src/';
$dir = '13358/';
$patharray = array_diff(scandir($path), array('..', '.',));
foreach($patharray as $pathinfo){
    $f2 = $path . $pathinfo;
    if(strpos($f2, '_2.html') !== false){
        $f1 = str_replace('_2.html', '.html', $f2);
        $c1 = file_get_contents($f1);
        $c1 = mb_convert_encoding($c1, 'UTF-8', 'gbk');
        # 提取 title
        preg_match('/<title>(.*?)<\/title>/', $c1, $title);
        $title = $title ? $title[1] : '';
        if(empty($title)) echo $pathinfo;
        $id = explode('章', $title)[0] . '章';
        # 提取上一章链接
        $link = explode('<a id="linkPrev"', $c1)[1];
        $link = explode('</a>', $link)[0];
        $link1 = '<a id="linkPrev"'. $link .'</a>';
        # 删除尾部 本章未完，点击下一页继续阅读
        $c1 = explode('<p class="text-danger text-center mg0">', $c1)[0];
        # 删除首部
        $array = explode($id, $c1);
        if(!isset($array[6])) echo $f1 .' '. $id ."\n\n";
        $c1 = $id . @$array[6];
        # 标题加 标签
        $title2 = explode('<br />', $c1, 2)[0];
        $c1 = str_replace($title2, '<h2>'.$title2.'</h2>', $c1);
        # 重写第一部分 $c1
        $title = explode('_', $title, 2)[1];
        $title = $title2 .'_'. $title;
        $c1 = add_head($title) . $c1;
        $c1 = str_replace(array(' &nbsp;', '&nbsp; ',), array('&nbsp;', '&nbsp;',), $c1);
        $c1 = str_replace(array('<br />&nbsp;', '<br />',), array('<p>&nbsp;', '</p>',), $c1);
        $c1 = str_replace('... -->>', '', $c1);
        $c1 = trim($c1) . '-->>';
        for($i=0; $i<100; $i++){
            $c1 = str_replace('&nbsp;', '', $c1);
        }
        $c1 = str_replace('</p></p>', '</p>', $c1);
        $c1 = str_replace('<p><p>', '<p>', $c1);
        $c1 = str_replace(array('&nbs-->>', '&nb-->>', '&n-->>', '<br-->>', '<-->>',), array('-->>', '-->>', '-->>', '-->>', '-->>',), $c1);


        $c2 = file_get_contents($f2);
        $c2 = mb_convert_encoding($c2, 'UTF-8', 'gbk');
        $c2 = explode('<br><br>', $c2, 2)[1]; # 无错无删减全文免费阅读！
        $c2 = str_replace('href="https://www.kfwx.cc/book/13358/"', 'href="index.html"', $c2);
        $c2 = str_replace(array(' &nbsp;', '&nbsp; ',), array('&nbsp;', '&nbsp;',), $c2);
        $c2 = str_replace(array('<br />&nbsp;', '<br />',), array('<p>&nbsp;', '</p>',), $c2);
        for($i=0; $i<100; $i++){
            $c2 = str_replace('&nbsp;', '', $c2);
        }
		$c2 = trim($c2);
        $c2 = str_replace('</p></p>', '</p>', $c2);
        $c2 = str_replace('<p><p>', '<p>', $c2);

        $str2 = mb_substr($c2, 0, 10);
		for($i=0; $i<10; $i++){
			$s = mb_substr($str2, 0, $i);
			$res = preg_match("/[\x7f-\xff]/", $s);
            if($res){break;}
		}
		$s = mb_substr($str2, 0, $i-1);
        $c2 = mb_substr($c2, $i-1);
        if(strpos($s, '<p>') !== false){ $c2 = '<p>'. $c2;}
        # 提取上一节链接
        $link = explode('<a id="linkPrev"', $c2)[1];
        $link = explode('</a>', $link)[0];
        $link2 = '<a id="linkPrev"'. $link .'</a>';





        $html = trim($c1) . trim($c2);
        $html = str_replace($link2, $link1, $html);
        $search = array(
                    "'<script[^>]*?>.*?</script>'si",     # 去掉javascript
                 /* "'<style[^>]*?>.*?</style>'si",       # 去掉css
                    "'<link[/!]*?[^<>]*?>'si",            # 去掉link  */
                );
        $replace = array("", "", "",);
        $html = preg_replace($search, $replace, $html);
        $html = str_replace('<a id="linkIndex"', '&nbsp;&nbsp;&nbsp;&nbsp;<a id="linkIndex"', $html);
        $html = str_replace('<a id="linkNext"', '&nbsp;&nbsp;&nbsp;&nbsp;<a id="linkNext"', $html);
        $html = str_replace('</div>', '', $html);
        $html = str_replace('<div class="col-md-4 col-md-offset-4">', '', $html);
        $html = str_replace('</body>', '</div><br><br></body>', $html);
        $html = str_replace('class="btn btn-default" ', '', $html);
        $html = str_replace('<p class="text-center readPager btn-group btn-group-justified" role="group">', '<p align="center">', $html);
        $html = str_replace('</h2></p>', '</h2>', $html);
        $html = str_replace('<br /> ', '<br />', $html);
        $html = str_replace(array('<br />&nbsp;', '<br />',), array('<p>&nbsp;', '</p>',), $html);
        $html = str_replace('<p align="center">', '</p><p align="center">', $html);
        
        $html = beautify_html($html);
        $f1 = str_replace($path, $dir, $f1);
        file_put_contents($f1, $html);
    }else{
        // echo $f2 . "\n\n";
        continue;
    }
}

# HTML 格式化
function beautify_html($html){
    require_once 'libs/beautify-html.php';
    $beautify_config = array(
        'indent_inner_html' => false,
        'indent_char' => " ",
        'indent_size' => 2,
        'wrap_line_length' => 32786,
        'unformatted' => ['code', 'pre', 'span'],
        'preserve_newlines' => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts'    => 'normal', // keep|separate|normal
        );
    $beautify = new Beautify_Html($beautify_config);
    $html = $beautify->beautify($html);
    return $html;
}


function add_head($title){
    $head = '
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <meta name="renderer" content="webkit">
  <meta name="force-rendering" content="webkit"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
  <meta name="referrer" content="no-referrer">

  <meta name="applicable-device" content="pc,mobile">
  <meta http-equiv="Cache-Control" content="no-transform" />
  <meta http-equiv="Cache-Control" content="no-siteapp" />
  <title>'. $title .'</title>
  <link rel="stylesheet" href="header-custom.css" type="text/css" media="screen"/>
  <!--<style type="text/css">div{background: #FDFEFE;}</style>-->
</head>
<body>
  <div id="article" class="margin-medium size-medium markdown_views">
';
    return $head;
}