<?php
$file = '13358/4403185.html';
$c = file_get_contents($file);
$article = article($c);
file_put_contents($file . '.txt', $article);
file_put_contents('13358.txt', $article);

$next = explode('<a id="linkNext" class="btn btn-default" href="', $c, 2)[1];
$next = explode('.html', $next, 2)[0];
$next = '13358/'. $next . '.html';

for($i=0; $i< 154; $i++){
	echo $next . "\r\n";
	if(strpos($next, '13358/4404144_2.html') !== false) break;
	$c = file_get_contents($next);
	$article = article($c);
    file_put_contents($next . '.txt', $article);
    file_put_contents('13358.txt', $article, FILE_APPEND);
	
    $next = explode('<a id="linkNext" class="btn btn-default" href="', $c, 2)[1];
    $next = explode('.html', $next, 2)[0];
    $next = '13358/'. $next . '.html';
}

function article($c){
	$article = explode('<div class="panel-body" id="htmlContent">', $c, 2)[1];
    $article = explode('</div>', $article, 2)[0];
    $article = str_replace('&nbsp;' , '', $article);
    $article = str_replace('        <br />' , '', $article);
    for($i = 0; $i < 100; $i++){
        $article = str_replace("\t", "    ",  $article);
        $article = str_replace("\r\n", "\n",  $article);
        $article = str_replace("\r", "\n",    $article);
        $article = str_replace(" \n", "\n",   $article);
        $article = str_replace("\n ", "\n",   $article);
        $article = str_replace("\n\n", "\n",  $article);
        $article = str_replace("  ", " ",  $article);
    }
    $article = str_replace("\n", "<br>\n",   $article);
    $article = str_replace("<br><br>", "<br>",   $article);
    $article = str_replace("<br />", "<br>",   $article);
    $article = str_replace("br />", "",   $article);
    $article = str_replace("<br>\n<br>\n<br>", "\n",   $article);
    $article = str_replace("<br>\n<br>", "",   $article);
    $article = trim($article);
	
	//if(strpos($article, '<p class="text-danger text-center mg0">���¡�δ�꣬�����һҳ�����Ķ�</p>') !== false){
    //    $article = str_replace('<p class="text-danger text-center mg0">���¡�δ�꣬�����һҳ�����Ķ�</p>', "",   $article);
	if(strpos($article, '... -->><br>') !== false){
        $article = explode('... -->><br>', $article, 2)[0];
    }else{
		$article .= "\n\n\n";
	}
	return $article;
}