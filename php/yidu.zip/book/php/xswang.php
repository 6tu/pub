<?php
$c = file_get_contents('d:/xs/xswang.cmd');
$c = str_replace('wget http://www.xswang.org/book/66086/', '', $c);
$c = str_replace('rem ', '', $c);
$c_array = explode("\r\n", $c);
foreach($c_array as $v){
	if(empty(trim($v))) continue;
    $file = 'd:/xs/'. trim($v);
	if(!file_exists($file)) continue;
	echo $file . "\r\n";
    $html = file_get_contents($file);

    $title1 = explode("<h1>", $html, 2)[1];
    $title = explode('<div class="lm">', $title1, 2)[0];
    $title_array = explode("\r\n", $title);
    $title = "<h1>" .$title_array[0]. $title_array[4].$title_array[7].$title_array[10] . "<br>\n";
	
    $main1 = explode('<p class="content_detail">', $html, 2)[1];
    $main = explode('<!-- <div align="center">', $main1, 2)[0];
    $article = $title . $main;
    $article = str_replace('<p class="content_detail">', '', $article);
    $article = str_replace('</p>', '', $article);

    for($i = 0; $i < 100; $i++){
        $article = str_replace("  ", " ",    $article);
        $article = str_replace("\t", "    ", $article);
        $article = str_replace(" <", "<",    $article);
        $article = str_replace("\r\n", "\n", $article);
        $article = str_replace("\r", "\n",   $article);
        $article = str_replace(" \n", "\n",  $article);
        $article = str_replace("\n\n", "\n", $article);
        $article = str_replace("\n<", "<",   $article);
        $article = str_replace("\n ", "\n",  $article);
    }
    $article = str_replace('><', ">　\n<", $article);

    file_put_contents($file .'.txt', $article);
	file_put_contents('d:/xs.txt', $article . "\r\n", FILE_APPEND);
}
