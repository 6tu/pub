<?php
$url = 'http://www.xswang.org/book/63156/68737970.html';
//$url = 'http://www.xswang.org/book/65298/65710002.html';
//$url = 'http://liuyun.org';

$pos = strrpos(substr($url, 0, -1), "/") + 1;
$file = substr($url, $pos);

$html_array = get_url_contents($url);
if(!empty($html_array['error'])) die($html_array['error']);

$html = $html_array['body'];
$html = preg_replace("/\r\n|\r|\n/", ' ', $html);
$html = preg_replace("/<\s+/is", "<", $html);
$html = preg_replace("/\s+>/is", ">", $html);

$meta_charset = get_meta_charset($html);
echo $meta_charset;
$charset = preg_match("/charset=[^\w]?([-\w]+)/i", $meta_charset, $temp) ? strtolower($temp[1]): "";
print_r($charset);

if(empty($charset)){
    $header = print_r($html_array['header'], true);
    $charset = preg_match("/charset=[^\w]?([-\w]+)/i", $header, $temp) ? strtolower($temp[1]): "";
    echo $charset;
}
if($charset !== 'utf-8' and !empty($charset)){
    $html = mb_convert_encoding($html, 'utf-8', $charset);
}
echo $file;
$html = beautify_html($html);
file_put_contents($file, $html);







/** ============================ 函数 ============================ */

# 获取url内容,返回数组
function get_url_contents($url){
    # 该链接的来源处/引用处
    $url_array = parse_url($url);
    $refer = $url_array['scheme'] . '://' . $url_array['host'] . '/';
    $pos = strrpos($url, '/', 0);
    $refer = substr($url, 0,$pos + 1);
    # 浏览器语言
    if(empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])){
        $lang = 'zh-CN,zh; q=0.9';
    }else $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    # 浏览器标识
    if(empty($_SERVER['HTTP_USER_AGENT'])){
        $useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36';
    }else $useragent = $_SERVER['HTTP_USER_AGENT'];

    $options = array(
        'http' => array(
            'method' => 'GET',
            'header' => "Accept-language: $lang\r\n" .
                        "Referer: $refer\r\n" .
                        "User-Agent: $useragent\r\n" .
                        "Cookie: foo=bar\r\n"
        ),
        "ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
        )
    );

    $context = stream_context_create($options);
    set_error_handler(function($err_severity, $err_msg, $err_file, $err_line, array$err_context){
        throw new ErrorException($err_msg, 0, $err_severity, $err_file, $err_line);
    }, E_WARNING);
    try{
        $body = file_get_contents($url, false, $context);
        $header = $http_response_header;
    }
    catch(Exception $e){
        $error = $e -> getMessage();
    }
    # restore the previous error handler 还原以前的错误处理程序
    restore_error_handler();
    if(!isset($body)) $body = NULL;
    if(!isset($header)) $header = NULL;
    if(!isset($error))$error = NULL;
    $res_array = array(
        'header' => $header,
        'body'   => $body,
        'error'  => $error,
    );
    return $res_array;
}

function get_meta_charset($html){
    // $charset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", $html, $temp) ? strtolower($temp[1]):"";
    $html = preg_replace("/\r\n|\r|\n/", ' ', $html);
    $html = preg_replace("/<\s+/is", "<", $html);
    $html = preg_replace("/\s+>/is", ">", $html);

    preg_match_all('/<meta.*?>/i', $html, $matches);
    $meta_charset = '';
    foreach($matches[0] as $value){
        $value = strtolower(trim($value));
         # 多个空格转为一个空格
        $value = preg_replace("/\s(?=\s)/", "\\1", $value);
         // $value = preg_replace("/ {2,}/", "", $value); # {2,}前面的空格不能少
        $value = preg_replace("/'/", '"', $value);
        $value = str_replace(array(' "', '=" '), array('"', '="'), $value);
        $value = str_replace(array('= ', ' ='), array('=', '='), $value);
        if(strpos($value, 'charset') !== false) $meta_charset .= $value . "\n";
    }
    return $meta_charset;
}

# HTML 格式化
function beautify_html($html){
    require_once 'libs/beautify-html.php';
    $beautify_config = array(
        'indent_inner_html' => false,
        'indent_char' => " ",
        'indent_size' => 2,
        'wrap_line_length' => 32786,
        'unformatted' => ['code', 'pre', 'span'],
        'preserve_newlines' => false,
        'max_preserve_newlines' => 32786,
        'indent_scripts' => 'normal', // keep|separate|normal
    );
    $beautify = new Beautify_Html($beautify_config);
    $html = $beautify -> beautify($html);
    return $html;
}
