<?php
$html = '
    <link rel="canonical" href="https://blog.csdn.net/allway2/article/details/112167456"/>
    <        meta charset   = "   utf-8      "   
    >          
    <link rel="canonical" href="https://blog.csdn.net/allway2/article/details/112167456"/>
    <META http-equiv=    "   content-type         \'              content="text/html; charset =   utf-8        ">
';
$meta_charset = get_meta_charset($html);
echo $meta_charset;
$charset = preg_match("/charset=[^\w]?([-\w]+)/i", $meta_charset, $temp) ? strtolower($temp[1]): "";
print_r($charset);
function get_meta_charset($html){
    // $charset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", $html, $temp) ? strtolower($temp[1]):"";
    $html = preg_replace("/<\s+/is", "<", $html);
    $html = preg_replace("/\s+>/is", ">", $html);
    $html = preg_replace("/\r\n|\r|\n/", ' ', $html);
    preg_match_all('/<meta.*?>/i', $html, $matches);
    $meta_charset = '';
    foreach($matches[0] as $value){
        $value = strtolower(trim($value));
         # 多个空格转为一个空格
        $value = preg_replace("/\s(?=\s)/", "\\1", $value);
         // $value = preg_replace("/ {2,}/", "", $value); # {2,}前面的空格不能少
        $value = preg_replace("/'/", '"', $value);
        $value = str_replace(array(' "', '=" '), array('"', '="'), $value);
        $value = str_replace(array('= ', ' ='), array('=', '='), $value);
        if(strpos($value, 'charset') !== false) $meta_charset .= $value . "\n";
    }
    return $meta_charset;
}

//if(empty($charset)){

// $header = print_r($header_array, true);
// $charset = preg_match("/charset=[^\w]?([-\w]+)/i", $header, $temp) ? strtolower($temp[1]): "";
// print_r($charset);









/**

preg_match_all('/<meta\s+.*?charset="(.*?)".*?>/si', $meta, $matches);
//print_r($matches);

preg_match_all('#<meta(?:\\s+?([^\\=]+)\\=\"(.+?)\")+?\\s*?/?>#sui', $meta, $matches, PREG_SET_ORDER);
//print_r($matches);

preg_match_all('/<meta[\s]?([^>"]*)charset="?([^>"]*)".*?>/si', $meta, $match);
//print_r($match);

 * preg_match_all('/<meta\s+.*?charset="(S+).*?>/si', $html, $matches);
 * print_r($matches);
 * 
 * preg_match_all('#<meta(?:\\s+?([^\\=]+)\\=\"(.+?)\")+?\\s*?/?>#sui', $html, $matches, PREG_SET_ORDER);
 * print_r($matches);
 * 
 * 
 * 
 * $array_type = explode(";", $array_headers['Content-Type']);
 * $mime_type = trim(strtolower($array_type[0]));
 * $charset = preg_match("/charset=[^\w]?([-\w]+)/i", $array_headers['Content-Type'], $temp) ? strtolower($temp[1]): "";
 * if(empty($charset)){
 * $charset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i",
 * $res_array[1], $temp) ? strtolower($temp[1]):"";
 * }
 * if(empty($array_headers['Content-Type'])){
 * $mime_type = '';
 * $charset =  '';
 * }
 */



