<?php
echo '<pre><br><b>';
$last=exec("/usr/bin/lastb", $res, $rc);
print_r($res);
$ip = '';
foreach($res as $value){
    $value = preg_replace('#\s+#', ' ', $value);
    
    $arr = explode(' ',$value);
    if(!empty($arr[2]) and strstr($arr[2],'.')){
    $ip .= @$arr[2]."\r\n";
    }
}
echo $ip;