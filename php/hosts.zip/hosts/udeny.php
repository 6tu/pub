<?php
system('cp hosts.deny.bak /etc/hosts.deny');
//system('echo -e "">> /etc/hosts.deny');
//system('echo -e "">> /etc/hosts.deny');

