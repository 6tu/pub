<?php
echo '<pre>';
system('cat /etc/hosts.deny');
