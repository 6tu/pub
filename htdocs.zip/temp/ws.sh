#!/bin/bash

apt update -y
apt install -y lrzsz unar zip unzip wget curl net-tools openssl libssl-dev gnupg

apt install -y mysql-server mysql-client
apt install -y sqlite3 libsqlite3-dev

apt install -y apache2 libapache2-mod-fcgid libapache2-mod-php spawn-fcgi php
apt install -y php-fpm php-cli php-common php-cgi 
apt install -y php-pdo php-mysql php-mysqli php-mysqlnd php-sqlite3 php-pgsql php-odbc
apt install -y php-gd php-curl php-intl php-tidy php-mbstring php-zip php-bz2
apt install -y php-json php-xml
apt install -y php-dev

a2enmod actions fcgid alias proxy_fcgi proxy

a2enmod ssl http2
a2ensite default-ssl.conf
systemctl reload apache2
mv /etc/apache2/sites-enabled/default-ssl.conf /etc/apache2/sites-enabled/001-default-ssl.conf
test -d /etc/apache2/ssl || mkdir -p /etc/apache2/ssl

systemctl restart apache2

apt install -y composer
composer update

test -d /home/tmp || mkdir -p /home/tmp

chown -R www-data:www-data  /var/www/html

