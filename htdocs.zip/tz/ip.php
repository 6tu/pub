<?php

# ETH0ORSIMILAR=$(ip route get 8.8.8.8 | awk -- '{printf $5}')
# IP=$(ifdata -pa $ETH0ORSIMILAR)
header("Content-type: text/html; charset=utf-8");
$company = 'hostdare >> ';
$nic = '[eth0]';
$ipinfo = @$_SERVER['SERVER_NAME'] . ' - ';
if('/' == DIRECTORY_SEPARATOR){
    $ipinfo = @$_SERVER['SERVER_ADDR'] . ' - ';
    }else{
    $ipinfo = @gethostbyname($_SERVER['SERVER_NAME']) . ' - ';
    }
// 这里需要自行设定/etc/issue
if(PHP_OS == 'Linux'){
    $kernel = substr(php_uname('r'), 0, stripos(php_uname('r'), '-'));
    // $os = file_get_contents('/etc/issue');
    $lastline = exec('cat /etc/issue', $res, $rc);
    $os = $res[0];
    $os = str_replace(array("\r\n", "\n", '\n', '\l'), '', $os);
    $os = trim($os) . ' - ' . $kernel;
    }else{
    $os = php_uname('s') . ' ' . php_uname('r');
    }
$apache = trim($_SERVER['SERVER_SOFTWARE']) . ' ';
$apache = substr($apache, 0, stripos($apache, ' '));
$s_info = $company . $nic . $ipinfo . $os . ' - ' . $apache . ' PHP/' . phpversion();

$c_ip = @$_SERVER['REMOTE_ADDR'];

// ajax调用实时刷新
if (!empty($_GET['act']) and $_GET['act'] == "rt"){
    $arr = array(
        'c_ip' => "$c_ip",
        's_info' => "$s_info",
        );
    $jarr = json_encode($arr);
    $_GET['callback'] = htmlspecialchars($_GET['callback']);
    echo $_GET['callback'],'(',$jarr,')';
    # exit;
}else{
    echo '<small>' . rand() . '</small><br><br><center><h3>';
    echo ' ' . $_SERVER['REMOTE_ADDR'] . "<br>\r\n";
    # if(isset($_SERVER['HTTP_FORWARDED'])) echo 'HTTP_FORWARDED: '. $_SERVER['HTTP_FORWARDED'] ."<br>\r\n";
    if(isset($_SERVER['HTTP_X_FORWARDED'])) echo 'HTTP_X_FORWARDED: ' . $_SERVER['HTTP_X_FORWARDED'] . "<br>\r\n";
    if(isset($_SERVER['HTTP_FORWARDED_FOR'])) echo 'HTTP_FORWARDED_FOR: ' . $_SERVER['HTTP_FORWARDED_FOR'] . "<br>\r\n";
    if(isset($_SERVER['HTTP_X_FORWARDED_FOR'])) echo 'HTTP_X_FORWARDED_FOR: ' . $_SERVER['HTTP_X_FORWARDED_FOR'] . "<br>\r\n";
    if(isset($_SERVER['HTTP_CLIENT_IP'])) echo 'HTTP_CLIENT_IP: ' . $_SERVER['HTTP_CLIENT_IP'] . "<br>\r\n";
    echo '</h3></center>';
}


