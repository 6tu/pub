<?php
define('KOD_VERSION','4.50');
define('KOD_VERSION_BUILD','01');//time(),20221117