<?php exit;?>{
    "1": {
        "name": "admin",
        "path": "admin",
        "password": "57675b893dab54d6de0b83956d18f39c",
        "userID": "1",
        "role": "1",
        "config": {
            "sizeMax": "0",
            "sizeUse": 1024
        },
        "groupInfo": {
            "1": "write"
        },
        "createTime": 1675870146,
        "status": 1,
        "lastLogin": 1675870168
    },
    "100": {
        "userID": "100",
        "name": "demo",
        "password": "fe01ce2a7fbac8fafaed7c982a04e229",
        "role": "2",
        "config": {
            "sizeMax": 5,
            "sizeUse": 1048576
        },
        "groupInfo": {
            "1": "write"
        },
        "path": "demo",
        "status": 1,
        "lastLogin": "",
        "createTime": 1675870146
    },
    "101": {
        "userID": "101",
        "name": "guest",
        "password": "084e0343a0486ff05530df6c705c8bb4",
        "role": "100",
        "config": {
            "sizeMax": 0.1,
            "sizeUse": 1048576
        },
        "groupInfo": {
            "1": "read"
        },
        "path": "guest",
        "status": 1,
        "lastLogin": "",
        "createTime": 1675870146
    }
}